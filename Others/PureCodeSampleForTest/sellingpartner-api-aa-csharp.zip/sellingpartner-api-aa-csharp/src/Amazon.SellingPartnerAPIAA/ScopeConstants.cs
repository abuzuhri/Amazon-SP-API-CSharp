﻿namespace Amazon.SellingPartnerAPIAA
{
    public class ScopeConstants
    {
        public const string ScopeNotificationsAPI = "sellingpartnerapi::notifications";
        public const string ScopeMigrationAPI = "sellingpartnerapi::migration";
    }
}
