﻿using Amazon.Runtime;
using Amazon.SecurityToken;
using Amazon.SecurityToken.Model;
using Amazon.SellingPartnerAPIAA;
using FikaAmazonAPI;
using FikaAmazonAPI.Parameter.Order;
using FikaAmazonAPI.Utils;
using RestSharp;
using static FikaAmazonAPI.Utils.Constants;

namespace PruebaAmazon
{
    class Program
    {
        public readonly static string DateISO8601Format = "yyyy-MM-ddTHH:mm:ss.fffZ";

        static void Main(string[] args)
        {
            

            Environment.SetEnvironmentVariable("AccessKey", "......");
            Environment.SetEnvironmentVariable("SecretKey", "");
            Environment.SetEnvironmentVariable("RoleArn", "arn:aws:iam::00000:role/0000000");
            Environment.SetEnvironmentVariable("ClientId", "amzn1.application-oa2-client.000000000000000");
            Environment.SetEnvironmentVariable("ClientSecret", "000000000000000000000000000000");
            Environment.SetEnvironmentVariable("RefreshToken", "Atzr|0-0-0");


            var date = DateTime.UtcNow.AddDays(-30).ToString(DateISO8601Format);
            var url = "/finances/v0/financialEvents?PostedAfter=" + date;
            string response = getResponse(url, Method.GET, false, null);


            
        }

        private static string getResponse(string endpoint, RestSharp.Method httpMethod, bool pruebas, Object body = null)
        {
            AssumeRoleResponse assumeRoleResponse = null;
            DateTime checkDate = DateTime.UtcNow.AddDays(-5);

            Task.Run(async () =>
            {
                assumeRoleResponse = await GetAssumeRoleTokenDetail();
            }).GetAwaiter().GetResult();

            string urlProduccion = "https://sellingpartnerapi-eu.amazon.com";
            string urlPruebas = "https://sandbox.sellingpartnerapi-eu.amazon.com/";
            RestClient restClient = new RestClient(!pruebas ? urlProduccion : urlPruebas);
            // IRestRequest restRequest = new RestRequest("orders/v0/orders/TEST_CASE_200/orderItems/buyerInfo", Method.GET);
            IRestRequest restRequest = new RestRequest(endpoint, httpMethod);

            restRequest.AddQueryParameter("MarketplaceIds", "A1RKKUPIHCS9HS");
            restRequest.AddQueryParameter("CreatedAfter", checkDate.ToString("yyyy-MM-ddTHH:mm:ssZ"));



            AWSAuthenticationCredentials AWSCredentials = new AWSAuthenticationCredentials();
            AWSCredentials.AccessKeyId = assumeRoleResponse.Credentials.AccessKeyId;
            AWSCredentials.SecretKey = assumeRoleResponse.Credentials.SecretAccessKey;
            AWSCredentials.Region = "eu-west-1";


            LWAAuthorizationCredentials LWACredentials = new LWAAuthorizationCredentials();
            LWACredentials.ClientId = Environment.GetEnvironmentVariable("ClientId");
            LWACredentials.ClientSecret = Environment.GetEnvironmentVariable("ClientSecret");
            LWACredentials.Endpoint = new Uri("https://api.amazon.com/auth/o2/token");
            LWACredentials.RefreshToken = Environment.GetEnvironmentVariable("RefreshToken");
            restRequest = new LWAAuthorizationSigner(LWACredentials).Sign(restRequest);

            restRequest.AddHeader("X-Amz-Security-Token", assumeRoleResponse.Credentials.SessionToken);

            if (httpMethod == Method.POST && body != null)
            {
                restRequest.AddJsonBody(body);
            }

            restRequest = new AWSSigV4Signer(AWSCredentials).Sign(restRequest, restClient.BaseUrl.Host);



            IRestResponse response = restClient.Execute(restRequest);

            return response.Content;
        }

        private static async Task<AssumeRoleResponse> GetAssumeRoleTokenDetail()
        {
            // AWS IAM user data, NOT seller central dev data
            var accessKey = Environment.GetEnvironmentVariable("AccessKey"); // get from users access key id from first step
            var secretKey = Environment.GetEnvironmentVariable("SecretKey"); // get from users secret key from first step

            var credentials = new BasicAWSCredentials(accessKey, secretKey);

            var client = new AmazonSecurityTokenServiceClient(credentials);

            var assumeRoleRequest = new AssumeRoleRequest()
            {
                DurationSeconds = 3600,
                // role ARN you create here: 
                // https://github.com/amzn/selling-partner-api-docs/blob/main/guides/developer-guide/SellingPartnerApiDeveloperGuide.md#step-4-create-an-iam-role
                RoleArn = Environment.GetEnvironmentVariable("RoleArn"),
                RoleSessionName = DateTime.Now.Ticks.ToString()
            };

            var assumeRoleResponse = await client.AssumeRoleAsync(assumeRoleRequest);

            Console.WriteLine(assumeRoleResponse.HttpStatusCode);

            return assumeRoleResponse;
        }
    }
}
